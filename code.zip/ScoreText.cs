﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEditor;

public class ScoreText : MonoBehaviour {

    public float score { get; set; }
    public float winScore;

    public bool timedDecrease;
    public float timeInSecs;
    public float value;
    public bool waitToDecrease;
    public float valueToWait;
    private float timer;


    public bool shouldDecrease { get; set; }

    private void Start ()
    {
        GetComponent<Text>().text = "SCORE:  " + score;
        score = 0f;
        timer = timeInSecs;
        shouldDecrease = false;
    }
	
    public void Update ()
    {
        if (score < 0)
            SceneManager.LoadScene("EndGameLoseScreen");
        if (score >= winScore)
            SceneManager.LoadScene("EndGameWinScreen");

        if (waitToDecrease)
            if (score >= valueToWait)
                shouldDecrease = true;

        if (shouldDecrease && timedDecrease)
        {
            if (timer >= 0)
                timer -= Time.deltaTime;
            else
            {
                score -= value;
                timer = timeInSecs;
                GetComponent<Text>().text = "SCORE:  " + score;
            }
        }

        print(shouldDecrease + "\n" + score + " , " + valueToWait);
    }

	public void UpdateScore (float value)
    {
        score += value;
        GetComponent<Text>().text = "SCORE:  " + score;
    }
}

[CustomEditor(typeof(ScoreText))]
public class ScoreTextEditor : Editor
{
    public override void OnInspectorGUI()
    {
        ScoreText st = (ScoreText)target;
        st.winScore = EditorGUILayout.FloatField("winScore", st.winScore);
        st.timedDecrease = EditorGUILayout.Toggle("Timed Decrease", st.timedDecrease);

        if (st.timedDecrease)
        {
            st.timeInSecs = EditorGUILayout.FloatField("Time in Seconds", st.timeInSecs);
            st.value = EditorGUILayout.FloatField("Value", st.value);
            st.waitToDecrease = EditorGUILayout.Toggle("Wait to Decrease", st.waitToDecrease);
            
            if (st.waitToDecrease)
            {
                st.valueToWait = EditorGUILayout.FloatField("Wait Score Value", st.valueToWait);
            }
        }
    }
}