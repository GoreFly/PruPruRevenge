﻿using UnityEngine;
using System.Collections;

public class Spawner : MonoBehaviour
{
	public GameObject[] objectPrefabs;

	public float maxSpawnTime;
    public float minSpawnTime;
    private float spawnTime;
	private float spawnTimer;

	public int minWaveCount;
	public int maxWaveCount;

    public bool isCapped;
    public int spawnCap;

	private bool isQuitting;

	private void Start()
	{
		spawnTimer = 0f;
	}

	private void Update()
	{
		// Add to the timer and check if it's time for a new wave
		spawnTimer += Time.deltaTime;

        // If number of objects the spawner spawn should be capped, count how many
        // objects there are and set the flag
        bool shouldSpawn = true;
        if (isCapped)
        {
            GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");
            if (enemies.Length >= spawnCap)
                shouldSpawn = false;
        } 

		if (spawnTimer >= spawnTime && shouldSpawn)
		{
			// Time to spawn a wave of objects!
			SpawnWave();

			// Reset the timer for the next wave
			spawnTimer = 0f;
		}
	}

	private void SpawnWave()
	{
		// First, determine how many objects we are going to spawn in this wave
		int waveCount = Random.Range(minWaveCount, maxWaveCount + 1);	// Random.Range(int, int) excludes the upper bound, so we increase by one to compensate

		for (int i = 0; i < waveCount; i++)
		{
			// We need to spawn one object in this iteration of the loop

			// Let's determine which objectPrefab to spawn by picking a random one out of the array
			int index = Random.Range(0, objectPrefabs.Length);
			GameObject objectPrefab = objectPrefabs[index];

            // We can now spawn it with Instantiate()
            GameObject instance = (GameObject) Instantiate(objectPrefab, transform.position, transform.rotation);

            // This is a very specific interaction with the MoveToPosition script
            MoveToPosition moveToPosition = (MoveToPosition)instance.GetComponent<MoveToPosition>();
            moveToPosition.startPosition = GetComponent<Transform>();
            moveToPosition.endPosition = transform.Find("Movepoint").GetComponent<Transform>();

            // For some reason the ScoreText in the enemy health component is disappearing, so we will
            // manually set it here. This is not right, but it is working...
            Health health = (Health)instance.GetComponent<Health>();
            if (health != null)
                health.scoreText = GameObject.FindWithTag("UI").GetComponentInChildren<ScoreText>();
		}

        // Set new Spawn Time
        spawnTime = Random.Range(minSpawnTime, maxSpawnTime + 1);
	}

}