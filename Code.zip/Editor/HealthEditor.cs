﻿using System.Collections;
using UnityEngine;

// Platform Dependent Compilation
#if UNITY_EDITOR
using UnityEditor;
#endif

[CustomEditor(typeof(Health))]
public class HealthEditor : Editor
{
    public override void OnInspectorGUI()
    {
        Health health = (Health)target;

        health.health = EditorGUILayout.FloatField("Health", health.health);
        health.maxHealth = EditorGUILayout.FloatField("Max Health", health.maxHealth);
        health.respawnOnDeath = EditorGUILayout.Toggle("Respawn On Death", health.respawnOnDeath);
        health.showHealth = EditorGUILayout.Toggle("Show Health", health.showHealth);
        health.invincibleAfterDeath = EditorGUILayout.Toggle("Invincible After Dying", health.invincibleAfterDeath);
        health.updateScore = EditorGUILayout.Toggle("Update Score", health.updateScore);

        if (health.updateScore)
        {
            health.scoreValue = EditorGUILayout.FloatField("Value", health.scoreValue);
            health.scoreText = (ScoreText)EditorGUILayout.ObjectField("GUI Score Text", health.scoreText, typeof(ScoreText), allowSceneObjects: true);
        }
    }
}