﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// Platform Dependent Compilation
#if UNITY_EDITOR
using UnityEditor;
#endif

[CustomEditor(typeof(ScoreText))]
public class ScoreTextEditor : Editor
{
    public override void OnInspectorGUI()
    {
        ScoreText st = (ScoreText)target;
        st.winScore = EditorGUILayout.FloatField("winScore", st.winScore);
        st.timedDecrease = EditorGUILayout.Toggle("Timed Decrease", st.timedDecrease);

        if (st.timedDecrease)
        {
            st.timeInSecs = EditorGUILayout.FloatField("Time in Seconds", st.timeInSecs);
            st.value = EditorGUILayout.FloatField("Value", st.value);
            st.waitToDecrease = EditorGUILayout.Toggle("Wait to Decrease", st.waitToDecrease);

            if (st.waitToDecrease)
            {
                st.valueToWait = EditorGUILayout.FloatField("Wait Score Value", st.valueToWait);
            }
        }
    }
}