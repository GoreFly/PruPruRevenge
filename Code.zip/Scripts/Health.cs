﻿using System.Collections;
using UnityEngine;

public class Health : MonoBehaviour
{
	public float health;
	public float maxHealth;

	private Transform respawn;
	public bool respawnOnDeath;

	//public AudioClip damageClip;
	//public AudioClip deathClip;
	//public AudioClip healClip;

	public bool showHealth;
	private Texture guiTex;

    public bool updateScore;
    public float scoreValue;
    public ScoreText scoreText;

    public bool invincibleAfterDeath;
    private bool invincible;

	private void Start()
	{
		// We want to start off with our max health
		health = maxHealth;

		if (showHealth)
			guiTex = new Texture2D(1,1,TextureFormat.ARGB32, false);
	}

	private void OnGUI()
	{
		if (showHealth == true)
		{
			GUI.color = new Color(0.8f, 0.8f, 0.8f, 1f);
			GUI.Label(new Rect(10, 10, Screen.width * 0.25f, 20), "Health");
			
			GUI.color = new Color(0.5f, 0.5f, 0.5f, 1f);
			GUI.DrawTexture(new Rect(10, 30, Screen.width * 0.25f, 30), guiTex);
			
			GUI.color = new Color(0.9f, 0.1f, 0.3f, 1f);
			GUI.DrawTexture(new Rect(15, 35, (Screen.width * 0.25f - 10) * (health / maxHealth), 20), guiTex);
		}
	}

    public void Damage(float damage)
    {
        if (!invincible)
        {
            // Subtract the damage from our total health
            health -= damage;

            // We don't want to go below zero health, so let's cap it off
            if (health < 0)
                health = 0;

            // Have we run out of health?
            if (health <= 0f)
            {
                // Yes we have!

                // Play sound
                //AudioSource.PlayClipAtPoint(deathClip, transform.position);

                // Can we respawn? If not, we'll just destroy ourselves...
                if (respawnOnDeath && respawn != null)
                {
                    Respawn();
                }
                else
                {

                    // Destroy(gameObject);
                    // For this game, we won't destroy, but activate running animation and
                    // make it slightly transparent
                    GetComponent<Animator>().SetTrigger(Animator.StringToHash("isHit"));
                    foreach (Material material in GetComponentInChildren<SkinnedMeshRenderer>().materials)
                    {
                        GetComponentInChildren<ShaderTransition>().ChangeRenderMode(material, ShaderTransition.BlendMode.Transparent);
                        material.color = new Color(1.0f, 1.0f, 1.0f, 0.5f);
                    }
                    GetComponent<MoveToPosition>().moveType = MoveToPosition.MoveType.OnceAndDestroy;

                }

                // Check if the "death" of this object means anything to a score system
                if (updateScore)
                {
                    // We need an object with ScoreText to update, so make sure we have it
                    if (scoreText != null)
                        scoreText.UpdateScore(scoreValue);
                }

                // Make invincible after health is depleted if necessary
                if (invincibleAfterDeath)
                    invincible = true;

                // If we have a damage or hurt sound, play it now
                //if (damageClip != null)
                //	AudioSource.PlayClipAtPoint(damageClip, transform.position);
            }
        }
    }

	public void Heal(float heal)
	{
		// Add the heal amount to our total health
		health += heal;
		
		// We don't want to heal beyond our max health, so cap it there
		if (health > maxHealth)
			health = maxHealth;

		// If we have a nice heal sound, time to play it
		//if (healClip != null)
		//	AudioSource.PlayClipAtPoint(healClip, transform.position);
	}

	public void Respawn()
	{
		transform.position = respawn.position;
		transform.rotation = respawn.rotation;

		GetComponent<Rigidbody>().velocity = Vector3.zero;
		GetComponent<Rigidbody>().angularVelocity = Vector3.zero;

		health = maxHealth;
	}

	public void SetRespawnCheckpoint(Transform respawn)
	{
		this.respawn = respawn;
	}
}