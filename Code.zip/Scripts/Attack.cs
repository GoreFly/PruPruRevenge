﻿using UnityEngine;
using System.Collections;

public enum AttackType { Primary, Secondary }

public abstract class Attack : MonoBehaviour
{
	public AttackType type;
	
	public float attackCooldownTime;
	private float attackCooldownTimer;

	public bool usesAmmo;
	public int ammo;
	public int maxAmmo;
	
	public AudioClip attackClip;
	public AudioClip noAmmoClip;

	private void Start()
	{
		// We want to be able to fire an attack right away, so let's set the timer to "finished"
		attackCooldownTimer = attackCooldownTime;

		OnStart();
	}

	protected virtual void OnStart() { }

	private void Update()
	{
		if (attackCooldownTimer < attackCooldownTime)
		{
			// We're still on cooldown, but update the timer so that we can fire in the future
			attackCooldownTimer += Time.deltaTime;
			if (attackCooldownTimer > attackCooldownTime)
				attackCooldownTimer = attackCooldownTime;
		}

		OnUpdate();
	}

	protected virtual void OnUpdate() { }

	public void FireAttack()
	{
		// If we're off cooldown, we can fire an attack
		if (attackCooldownTimer >= attackCooldownTime)
		{
			if (!usesAmmo || ammo > 0)
			{
				OnFireAttack();
				
				// If this attack uses ammo, we need to decrease its count by one
				if (usesAmmo)
					ammo--;
				
				// If we have a cool sound clip, let's play it!
				if (attackClip != null)
					AudioSource.PlayClipAtPoint(attackClip, transform.position);

				attackCooldownTimer = 0f;
			}
			else
			{
				// We don't have enough ammo to attack! If we have an audio clip,
				// let's play it to convey this...
				if (noAmmoClip != null)
					AudioSource.PlayClipAtPoint(noAmmoClip, transform.position);
			}
		}
	}

	protected abstract void OnFireAttack();

	public void IncreaseAmmo(int increase)
	{
		ammo += increase;

		if (ammo > maxAmmo)
			ammo = maxAmmo;
	}

	public void DecreaseAmmo(int decrease)
	{
		ammo -= decrease;

		if (ammo < 0)
			ammo = 0;
	}
}