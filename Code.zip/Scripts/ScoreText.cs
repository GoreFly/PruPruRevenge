﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ScoreText : MonoBehaviour {

    public float score { get; set; }
    public float winScore;

    public bool timedDecrease;
    public float timeInSecs;
    public float value;
    public bool waitToDecrease;
    public float valueToWait;
    private float timer;


    public bool shouldDecrease { get; set; }

    private void Start ()
    {
        GetComponent<Text>().text = "SCORE:  " + score;
        score = 0f;
        timer = timeInSecs;
        shouldDecrease = false;
    }
	
    public void Update ()
    {
        if (score < 0)
            SceneManager.LoadScene("EndGameLoseScreen");
        if (score >= winScore)
            SceneManager.LoadScene("EndGameWinScreen");

        if (waitToDecrease)
            if (score >= valueToWait)
                shouldDecrease = true;

        if (shouldDecrease && timedDecrease)
        {
            if (timer >= 0)
                timer -= Time.deltaTime;
            else
            {
                score -= value;
                timer = timeInSecs;
                GetComponent<Text>().text = "SCORE:  " + score;
            }
        }

        print(shouldDecrease + "\n" + score + " , " + valueToWait);
    }

	public void UpdateScore (float value)
    {
        score += value;
        GetComponent<Text>().text = "SCORE:  " + score;
    }
}