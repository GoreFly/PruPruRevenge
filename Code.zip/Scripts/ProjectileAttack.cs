﻿using UnityEngine;
using System.Collections;

public class ProjectileAttack : Attack
{
	public Projectile projectilePrefab;
	
	public Transform[] projectileLaunchers;
	private int projectileLauncherIndex;

	protected override void OnFireAttack()
	{
		// Let's first figure out where we want to fire the projectile from
		Transform fireTransform;
		
		// If we haven't defined any launchers, let's just use our transform
		if (projectileLaunchers == null || projectileLaunchers.Length == 0)
		{
			fireTransform = transform;
		}
		// Otherwise, we'll pick the next launcher in our array
		else
		{
			fireTransform = projectileLaunchers[projectileLauncherIndex];
		}
		
		// Now we can spawn the projectile!
		Instantiate(projectilePrefab, fireTransform.position, fireTransform.rotation);
		
		// Increase the launcher index so that we can fire from the next launcher next time we fire,
		// wrapping back around to the first index if necessary
		projectileLauncherIndex++;
		if (projectileLauncherIndex >= projectileLaunchers.Length)
			projectileLauncherIndex -= projectileLaunchers.Length;
	}
}