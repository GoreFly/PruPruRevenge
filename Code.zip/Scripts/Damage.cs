﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Damage : MonoBehaviour
{
	public float damage;

	public float damageRadius;

	public float damageCooldownTime;
	private float damageCooldownTimer;

	public bool damageOverTime;

	public bool damageOnTrigger;

	private void Start()
	{
		// We want to be able to deal damage right away, so let's set the timer to "finished"
		damageCooldownTimer = damageCooldownTime;
	}

	private void Update()
	{
		// Update the cooldown timer so that we can deal damage again
		if (damageCooldownTimer < damageCooldownTime)
		{
			damageCooldownTimer += Time.deltaTime;
			if (damageCooldownTimer > damageCooldownTime)
				damageCooldownTimer = damageCooldownTime;
		}
	}

	// We want to try to apply damage right when we enter the trigger in case this object
	// will get destroyed later
	private void OnTriggerEnter(Collider collider)
	{
		if (damageOnTrigger)
			ApplyDamage(collider);
	}

	// Since we can deal damage continuously or intermittently on a coolodwn, we need to
	// try to apply damage every frame a collider is in our trigger
	private void OnTriggerStay(Collider collider)
	{
		if (damageOnTrigger)
			ApplyDamage(collider);
	}

	// We want to try to apply damage right when we enter the collision in case this object
	// will get destroyed later
	private void OnCollisionEnter(Collision collision)
	{
		if (!damageOnTrigger)
			ApplyDamage(collision.collider);
	}

	// Since we can deal damage continuously or intermittently on a coolodwn, we need to
	// try to apply damage every frame we are in a collision
	private void OnCollisionStay(Collision collision)
	{
		if (!damageOnTrigger)
			ApplyDamage(collision.collider);
	}

	private void ApplyDamage(Collider collider)
	{
		// We want to only deal damage if we're off cooldown
		if (damageCooldownTimer >= damageCooldownTime)
		{
			List<Collider> colliderList;

			if (damageRadius > 0)
				colliderList = new List<Collider>(Physics.OverlapSphere(transform.position, damageRadius));
			else
				colliderList = new List<Collider>();

			if (!colliderList.Contains(collider))
				colliderList.Add(collider);

			for (int i = 0; i < colliderList.Count; i++)
			{
				collider = colliderList[i];

				// We can only deal damage to objects with health, so make sure it has health
				Health health = collider.GetComponent<Health>();
              
				if (health != null)
				{
					// If we want to deal damage over time, we need to scale the damage to account
					// for the time that has elapsed since the last frame
					if (damageOverTime)
						health.Damage(damage * Time.deltaTime);
					// Otherwise, just deal the damage upfront
					else
						health.Damage(damage);

					// Reset the cooldown to avoid dealing full damage every frame
					damageCooldownTimer = 0f;
				}
			}
		}
	}

	private void OnDrawGizmos()
	{
		Gizmos.color = Color.red;
		Gizmos.DrawWireSphere(transform.position, damageRadius);
	}
}