﻿using UnityEngine;
using System.Collections;

public class MoveToPosition : MonoBehaviour
{
	public enum MoveType { Once, OnceAndDestroy, Loop, PingPong }

	public Transform startPosition;
	public Transform endPosition;

	public Transform previousPosition { get; set; }
	public Transform targetPosition { get; set; }

    public float moveTime;
	private float moveTimer;

	public MoveType moveType;

	public bool moveOnStart;
	public bool matchRotation;

	private void Start()
	{
		transform.position = startPosition.position;
		if (matchRotation)
			transform.rotation = startPosition.rotation;
		
		previousPosition = startPosition;
		targetPosition = endPosition;

		enabled = moveOnStart;
	}

	private void Update()
	{
		moveTimer += Time.deltaTime;
		if (moveTimer >= moveTime)
			moveTimer = moveTime;

		float i = moveTimer / moveTime;

		transform.position = Vector3.Lerp(previousPosition.position, targetPosition.position, i);

		if (moveTimer >= moveTime)
		{
			switch (moveType)
			{
			    case MoveType.Once:
			        {
				        enabled = false;
				        break;
			        }
                case MoveType.OnceAndDestroy:
                    {
                        enabled = false;
                        Destroy(gameObject);

                        break;
                    }
			    case MoveType.Loop:
			        {
				        moveTimer = 0f;

				        break;
			        }
			    case MoveType.PingPong:
			        {
				        Transform swap = previousPosition;
				        previousPosition = targetPosition;
				        targetPosition = swap;

                        if (matchRotation)
                            transform.rotation = new Quaternion(transform.rotation.x, -transform.rotation.y, transform.rotation.z, transform.rotation.w);

				        moveTimer = 0f;

				        break;
			        }
			    default:
				    break;
			}
		}
	}

	public void Move()
	{
		enabled = true;
	}

	public void Stop()
	{
		enabled = false;
	}
}