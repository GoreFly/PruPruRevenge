﻿using UnityEngine;
using System.Collections;

public class Projectile : MonoBehaviour
{
	public float speed;

	public float lifeTime;
	private float lifeTimer;

	public bool useRigidbodyPhysics;

	public GameObject explosionParticles;

	public AudioClip destroyClip;

    public bool updateScore;

	private void Start()
	{
		lifeTimer = 0f;

		if (useRigidbodyPhysics)
			GetComponent<Rigidbody>().velocity = transform.up * -1 * speed;
	}

	private void Update()
	{
		// Move the projectile along its forward axis at a given speed,
		// making sure to account for the length of time since the last Update()
		if (!useRigidbodyPhysics)
		{
			// transform.position += transform.forward * speed * Time.deltaTime;
			GetComponent<Rigidbody>().MovePosition(transform.position + transform.up * speed * Time.deltaTime);
			GetComponent<Rigidbody>().velocity = Vector3.zero;
		}

		// We don't want the projectile to last forever if the player shoots
		// into the void (that would be a memory leak!), so we'll destroy
		// it after a while...
		lifeTimer += Time.deltaTime;
		if (lifeTimer >= lifeTime)
			Destroy(gameObject);
	}

	private void OnCollisionEnter(Collision collision)
	{
		// We can instantiate some cool particles as part of the collision!
		if (explosionParticles != null)
			Instantiate(explosionParticles, transform.position, transform.rotation);

		// We can play a cool sound when this projectile collides with something
		if (destroyClip != null)
			AudioSource.PlayClipAtPoint(destroyClip, transform.position);

		// We just hit something! Time to destroy ourselves...
		Destroy(gameObject);
	}
}