﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightScript : MonoBehaviour {

    public bool lightEnabled;

	void Start () {
        GameObject lightGameObject = new GameObject("The Light");
        Light lightComp = lightGameObject.AddComponent<Light>();
        lightComp.color = Color.blue;
        lightComp.intensity = 1;
        lightComp.enabled = lightEnabled;  
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
