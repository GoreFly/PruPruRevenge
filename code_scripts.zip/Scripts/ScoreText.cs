﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreText : MonoBehaviour {

    private float score = 0;

    private void Start ()
    {
        GetComponent<Text>().text = "SCORE:  " + score;
    }
	
	public void UpdateScore (float val)
    {
        score += val;
        GetComponent<Text>().text = "SCORE:  " + score;
    }
}
