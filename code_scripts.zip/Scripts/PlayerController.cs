﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    public float speed = 2.0f;
    public float boundOffset;
    public float rotationSpeed = 10.0f;

    private Vector3 rotDir = Vector3.zero;

    void Update () {        
        // Move Right
        if ((Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)) 
            && Camera.main.WorldToScreenPoint(transform.position).x < Screen.width - boundOffset)
        {
            transform.position += Vector3.right * speed * Time.deltaTime;
            rotDir = new Vector3(0, 0, 1);
        }

        // Move Left
        if ((Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A)) 
            && Camera.main.WorldToScreenPoint(transform.position).x > 0 + boundOffset)
        {
            transform.position += Vector3.left * speed * Time.deltaTime;
            rotDir = new Vector3(0, 0, -1);
        }

        // Shoot
        if (Input.GetKey(KeyCode.Space))
        {
            gameObject.GetComponent<ProjectileAttack>().FireAttack();
        }

        // Update object rotation
        if (rotDir != Vector3.zero)
        {
            transform.rotation = Quaternion.Slerp(
                transform.rotation,
                Quaternion.LookRotation(rotDir),
                Time.deltaTime * rotationSpeed
            );
        }
    }
}
