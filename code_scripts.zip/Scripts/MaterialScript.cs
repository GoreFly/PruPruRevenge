﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MaterialScript : MonoBehaviour {

    public Color color;
    public Texture texture;
    public Shader shader;

	void Start () {
        gameObject.GetComponent<Renderer>().material.color = color;
        gameObject.GetComponent<Renderer>().material.mainTexture = texture;
        gameObject.GetComponent<Renderer>().material.shader = shader;
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
